
window.addEventListener('contextmenu', function (e) {
    document.body.innerHTML += '<p></p>'
    alert("Not so fast. Right click has been disabled. Prove me you're a true developer too access my source code");
    e.preventDefault();
  }, false);






// flag (2/3) _p@ct_