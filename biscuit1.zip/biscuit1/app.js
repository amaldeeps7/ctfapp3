var express = require('express')
var createError = require('http-errors')
var path = require('path')
var cookieParser = require('cookie-parser')
const port = 7000

// Importing all the routes
const methodsroute=require("./routes/methods.js")
const robotsroute=require("./routes/robots.js")
const robotsflagroute=require("./routes/726f626f7473313233.js")
const biscuitsroute=require("./routes/biscuits.js")

var app = express()


// Mapping the EJS template engine to ".html" files
app.engine('html', require('ejs').renderFile);

app.use(express.static(path.join(__dirname, 'public')));

// Handling routes request
app.use("/",methodsroute)
app.use("/",robotsroute)
app.use("/",robotsflagroute)
app.use("/",biscuitsroute)

app.get('/', (req, res) => {
  res.render('biscuits.html')
})

//Robots.txt
app.use('/robots.txt', function(req, res, next) {
    res.type('text/plain')
    res.send("User-agent: *\nDisallow: /726f626f7473313233\nDisallow: /\nDisallow: /");
  });

app.listen(port, () => {
  console.log(`App listening on port ${port}`)
})