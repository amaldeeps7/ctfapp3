## Description

Biscuits, Robots, Nethods

## Requirements

- Nodejs
- expressjs (npm install expressjs)
- ejs (npm install ejs)
- cookie-parser (npm install cookie-parser)

## Installation and Deployment
You can either run in docker or directly using node command

### Docker

sudo docker-compose build
sudo docker-compose up

### node

node app.js

The app will be running in localhost:7000

## Hosting

Inorder to host the challenge. Deploy a linux machine in AWS ec2 or by using any other method and then install this app in that machine. The app will be ascessible at http://<your_public_ip>:7000