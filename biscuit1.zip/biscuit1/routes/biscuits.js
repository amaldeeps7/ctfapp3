// Importing the module
const express=require("express")
const cookieParser = require('cookie-parser')

// Creating express Router
const router=express.Router()

router.use(cookieParser());

router.get('/biscuits', (req, res) => {
    const cookie = req.cookies.flavour;
    if (cookie === 'Y2hvY29sYXRlZ2luZ2Vy') {
        res.send('flag{biscuits_flag} : Robots have concured the world!!!');
        return;
    }
    res.cookie('flavour','c3RyYXdiZXJyeQ==');
    res.render("biscuits.html")
});

module.exports=router