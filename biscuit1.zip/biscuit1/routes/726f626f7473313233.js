// Importing the module
const express=require("express")

// Creating express Router
const router=express.Router()

// Handling login request
router.get("/726f626f7473313233",(req,res,next)=>{
    res.send('flag{robots_flag}');
})
module.exports=router
