// Importing the module
const express=require("express")

// Creating express Router
const router=express.Router()

// Handling request
router.get('/methods', function(req, res, next) {
    res.send('Send me POST and i will give you the flag!!!');
  })
  
router.post('/methods', (req, res) => {
    res.send('flag{methods_flag}');
  })

module.exports=router
