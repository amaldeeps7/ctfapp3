// Importing the module
const express=require("express")

// Creating express Router
const router=express.Router()

// Handling login request
router.get("/robots",(req,res,next)=>{
    // res.send("This is the robots request")
    res.render("robots.html")
})
module.exports=router
